## Tested only on Ubuntu 20.04<br>
  
  ```html
 apt-get update && apt-get upgrade -y && apt dist-upgrade -y && update-grub && reboot
 ```
## Installation Link<br>

  ```html
sysctl -w net.ipv6.conf.all.disable_ipv6=1 && sysctl -w net.ipv6.conf.default.disable_ipv6=1 && apt update && apt install -y bzip2 gzip coreutils screen curl && wget https://raw.githubusercontent.com/NeGamer01/Autoscript-vpn/main/setupku.sh && chmod +x setupku.sh && ./setupku.sh
  ```
## Fitur:
<br>
✅ SSH WEBSOCKET TLS & NON-TLS 443/80 MULTIPATH<br>
✅ XRAY VMESS WEBSOCKET TLS & NON-TLS 443/80 MULTIPATH<br>
✅ XRAY VLESS WEBSOCKET TLS & NON-TLS 443/80<br>
✅ XRAY TROJAN WEBSOCKET TLS & NON-TLS 443/80<br>
✅ XRAY TROJAN TCP XTLS 443<br>
✅ XRAY TROJAN TCP TLS 443<br>
<br>
Registrasi IP 
:<a href="https://t.me/" target=”_blank”><img src="https://img.shields.io/static/v1?style=for-the-badge&logo=Telegram&label=Telegram&message=Click%20Here&color=blue"></a><br>

## SS

![Screenshot_20230404-154004_Termius](https://user-images.githubusercontent.com/86614702/229739373-d5c7f4a0-996b-4225-aeb5-b814e30ddaa7.jpg)
